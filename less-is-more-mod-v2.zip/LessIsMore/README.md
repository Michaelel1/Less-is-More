# Less Is More — A Balatro Joker Mod

A single Steamodded joker that scales with low cards.

> **Less Is More** *(Uncommon, $6)* — This Joker gains **+4 Mult** for every Ace, 2, 3, 4, or 5 scored.

## Requirements

1. [Lovely Injector](https://github.com/ethangreen-dev/lovely-injector) installed for Balatro.
2. [Steamodded](https://github.com/Steamodded/smods) installed (drop the `Mods` folder into your Balatro save directory).

## Install

Copy the entire `LessIsMore/` folder into your Balatro `Mods/` directory:

- **Windows:** `%AppData%\Balatro\Mods\LessIsMore\`
- **macOS:** `~/Library/Application Support/Balatro/Mods/LessIsMore/`
- **Linux:** `~/.local/share/Balatro/Mods/LessIsMore/`

Final layout should look like:

```
Mods/LessIsMore/
├── LessIsMore.lua
└── assets/
    ├── 1x/j_less_is_more.png
    └── 2x/j_less_is_more.png
```

Launch Balatro — Steamodded should list the mod on the main menu.

## Testing it quickly

Open the in-game console (Steamodded enables it via `~`) and spawn the joker:

```
SMODS.add_card({ key = 'j_lim_less_is_more' })
```

Or jump straight to a high-ante run with the Debug menu (`F2`) and buy it from the shop when it rolls.

## Tweaking

Open `LessIsMore.lua` and edit the `config.extra` table:

- `mult_gain` — how much Mult is added per qualifying card (default `4`).
- `mult` — starting Mult value (default `0`).

The qualifying ranks live inside the `calculate` function — look for `rank == 14 or (rank >= 2 and rank <= 5)` and adjust as you like (e.g., extend to `<= 6` to include 6s).

## Replacing the art

The included sprite is a placeholder. To swap in your own:

1. Export a **71×95** PNG to `assets/1x/j_less_is_more.png`.
2. Export a **142×190** PNG to `assets/2x/j_less_is_more.png`.
3. Restart Balatro.

That's it — no code changes needed.
