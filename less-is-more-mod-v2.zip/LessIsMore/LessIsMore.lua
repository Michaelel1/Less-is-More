--- STEAMODDED HEADER
--- MOD_NAME: Less Is More
--- MOD_ID: LessIsMore
--- MOD_AUTHOR: [Michael]
--- MOD_DESCRIPTION: A test pack: 11 custom Jokers exploring different scoring mechanics.
--- PREFIX: lim
--- BADGE_COLOUR: 4F6367
--- VERSION: 1.0.0

----------------------------------------------
------------MOD CODE -------------------------

----------------------------------------------------------------------
-- ATLASES (one per Joker for easy art swapping)
----------------------------------------------------------------------

local function atlas(key) SMODS.Atlas { key = key, path = "j_"..key..".png", px = 71, py = 95 } end

atlas("less_is_more")
atlas("snowball")
atlas("echo_chamber")
atlas("bookkeeper")
atlas("suited_booted")
atlas("coin_toss")
atlas("night_owl")
atlas("glass_cannon")
atlas("cardinal")
atlas("time_bomb")
atlas("gambler")

----------------------------------------------------------------------
-- 1. Less Is More  (Uncommon, $6) — +Mult per low card scored.
----------------------------------------------------------------------
SMODS.Joker {
    key = "less_is_more",
    loc_txt = {
        name = "Less Is More",
        text = {
            "This Joker gains {C:mult}+#1#{} Mult",
            "for every {C:attention}Ace{}, {C:attention}2{}, {C:attention}3{},",
            "{C:attention}4{}, or {C:attention}5{} scored",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 4, mult = 0 } },
    rarity = 2, cost = 6, atlas = "less_is_more", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local played = context.other_card
            if played and not played.debuff then
                local rank = played:get_id()
                if rank and (rank == 14 or (rank >= 2 and rank <= 5)) then
                    card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
                    return {
                        extra = { focus = card, message = localize("k_upgrade_ex") },
                        card = card, colour = G.C.MULT
                    }
                end
            end
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return {
                mult_mod = card.ability.extra.mult,
                message = localize{ type = "variable", key = "a_mult", vars = { card.ability.extra.mult } },
                colour = G.C.MULT
            }
        end
    end
}

----------------------------------------------------------------------
-- 2. Snowball  (Common, $5) — Scaling XMult per card discarded.
----------------------------------------------------------------------
SMODS.Joker {
    key = "snowball",
    loc_txt = {
        name = "Snowball",
        text = {
            "Gains {X:mult,C:white}X#1#{} Mult",
            "for every card discarded",
            "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { x_mult_gain = 0.05, x_mult = 1 } },
    rarity = 1, cost = 5, atlas = "snowball", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult_gain, card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.discard and not context.blueprint then
            card.ability.extra.x_mult = card.ability.extra.x_mult + card.ability.extra.x_mult_gain
            return {
                extra = { focus = card, message = localize("k_upgrade_ex") },
                card = card, colour = G.C.MULT
            }
        end
        if context.joker_main and card.ability.extra.x_mult > 1 then
            return {
                x_mult = card.ability.extra.x_mult,
                message = localize{ type = "variable", key = "a_xmult", vars = { card.ability.extra.x_mult } }
            }
        end
    end
}

----------------------------------------------------------------------
-- 3. Echo Chamber  (Uncommon, $7) — Retriggers leftmost scored card.
----------------------------------------------------------------------
SMODS.Joker {
    key = "echo_chamber",
    loc_txt = {
        name = "Echo Chamber",
        text = {
            "Retriggers the {C:attention}leftmost{}",
            "scored card {C:attention}#1#{} additional time"
        }
    },
    config = { extra = { repetitions = 1 } },
    rarity = 2, cost = 7, atlas = "echo_chamber", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.repetitions } }
    end,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play
                and context.scoring_hand and context.other_card == context.scoring_hand[1] then
            return {
                message = localize("k_again_ex"),
                repetitions = card.ability.extra.repetitions,
                card = card
            }
        end
    end
}

----------------------------------------------------------------------
-- 4. Bookkeeper  (Common, $4) — +1 hand size.
----------------------------------------------------------------------
SMODS.Joker {
    key = "bookkeeper",
    loc_txt = {
        name = "Bookkeeper",
        text = { "{C:attention}+#1#{} hand size" }
    },
    config = { extra = { h_size = 1 } },
    rarity = 1, cost = 4, atlas = "bookkeeper", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.h_size } }
    end,
    add_to_deck = function(self, card, from_debuff)
        G.hand:change_size(card.ability.extra.h_size)
    end,
    remove_from_deck = function(self, card, from_debuff)
        G.hand:change_size(-card.ability.extra.h_size)
    end
}

----------------------------------------------------------------------
-- 5. Suited & Booted  (Uncommon, $6) — +Chips per same-suit-as-leftmost.
----------------------------------------------------------------------
SMODS.Joker {
    key = "suited_booted",
    loc_txt = {
        name = "Suited & Booted",
        text = {
            "{C:chips}+#1#{} Chips per scored card",
            "with the same suit as the",
            "{C:attention}leftmost{} scored card"
        }
    },
    config = { extra = { chips = 30 } },
    rarity = 2, cost = 6, atlas = "suited_booted", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local played = context.other_card
            local first = context.scoring_hand and context.scoring_hand[1]
            if played and first and not played.debuff then
                local match_suit
                for _, s in ipairs({ "Spades", "Hearts", "Diamonds", "Clubs" }) do
                    if first:is_suit(s) then match_suit = s; break end
                end
                if match_suit and played:is_suit(match_suit) then
                    return { chips = card.ability.extra.chips, card = card }
                end
            end
        end
    end
}

----------------------------------------------------------------------
-- 6. Coin Toss  (Common, $5) — 50/50 +Chips or +Mult per scored card.
----------------------------------------------------------------------
SMODS.Joker {
    key = "coin_toss",
    loc_txt = {
        name = "Coin Toss",
        text = {
            "Each scored card has an even",
            "chance to give {C:chips}+#1#{} Chips",
            "or {C:mult}+#2#{} Mult"
        }
    },
    config = { extra = { chips = 30, mult = 6 } },
    rarity = 1, cost = 5, atlas = "coin_toss", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local played = context.other_card
            if played and not played.debuff then
                if pseudorandom("lim_coin_toss") < 0.5 then
                    return { chips = card.ability.extra.chips, card = card }
                else
                    return { mult = card.ability.extra.mult, card = card }
                end
            end
        end
    end
}

----------------------------------------------------------------------
-- 7. Night Owl  (Rare, $8) — XMult only on the final hand of the round.
----------------------------------------------------------------------
SMODS.Joker {
    key = "night_owl",
    loc_txt = {
        name = "Night Owl",
        text = {
            "{X:mult,C:white}X#1#{} Mult on your",
            "{C:attention}final hand{} of each round"
        }
    },
    config = { extra = { x_mult = 3 } },
    rarity = 3, cost = 8, atlas = "night_owl", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and G.GAME.current_round.hands_left == 0 then
            return {
                x_mult = card.ability.extra.x_mult,
                message = localize{ type = "variable", key = "a_xmult", vars = { card.ability.extra.x_mult } }
            }
        end
    end
}

----------------------------------------------------------------------
-- 8. Glass Cannon  (Rare, $8) — Big XMult that decays each round.
----------------------------------------------------------------------
SMODS.Joker {
    key = "glass_cannon",
    loc_txt = {
        name = "Glass Cannon",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "Loses {X:mult,C:white}X#2#{} Mult after each round",
            "{C:inactive}(min {X:mult,C:white}X1{C:inactive} Mult)"
        }
    },
    config = { extra = { x_mult = 3, decay = 0.25 } },
    rarity = 3, cost = 8, atlas = "glass_cannon", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult, card.ability.extra.decay } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and card.ability.extra.x_mult > 1 then
            return {
                x_mult = card.ability.extra.x_mult,
                message = localize{ type = "variable", key = "a_xmult", vars = { card.ability.extra.x_mult } }
            }
        end
        if context.end_of_round and not context.repetition and not context.individual and not context.blueprint then
            local new_v = math.max(1, card.ability.extra.x_mult - card.ability.extra.decay)
            if new_v ~= card.ability.extra.x_mult then
                card.ability.extra.x_mult = new_v
                return { message = "Cracked!", colour = G.C.RED, card = card }
            end
        end
    end
}

----------------------------------------------------------------------
-- 9. Cardinal  (Common, $5) — +Chips per scored Heart.
----------------------------------------------------------------------
SMODS.Joker {
    key = "cardinal",
    loc_txt = {
        name = "Cardinal",
        text = {
            "{C:chips}+#1#{} Chips for each",
            "{C:hearts}Heart{} card scored"
        }
    },
    config = { extra = { chips = 25 } },
    rarity = 1, cost = 5, atlas = "cardinal", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local played = context.other_card
            if played and not played.debuff and played:is_suit("Hearts") then
                return { chips = card.ability.extra.chips, card = card }
            end
        end
    end
}

----------------------------------------------------------------------
-- 10. Time Bomb  (Uncommon, $7) — Gains +Mult per Blind defeated.
----------------------------------------------------------------------
SMODS.Joker {
    key = "time_bomb",
    loc_txt = {
        name = "Time Bomb",
        text = {
            "Gains {C:mult}+#1#{} Mult per",
            "{C:attention}Blind{} defeated while owned",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 12, mult = 0 } },
    rarity = 2, cost = 7, atlas = "time_bomb", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.repetition and not context.individual and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
            return {
                extra = { focus = card, message = localize("k_upgrade_ex") },
                card = card, colour = G.C.MULT
            }
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return {
                mult_mod = card.ability.extra.mult,
                message = localize{ type = "variable", key = "a_mult", vars = { card.ability.extra.mult } },
                colour = G.C.MULT
            }
        end
    end
}

----------------------------------------------------------------------
-- 11. Gambler's Pact  (Rare, $8) — Per-card chance for XMult.
----------------------------------------------------------------------
SMODS.Joker {
    key = "gambler",
    loc_txt = {
        name = "Gambler's Pact",
        text = {
            "{C:green}#1# in #2#{} chance for each",
            "scored card to give {X:mult,C:white}X#3#{} Mult"
        }
    },
    config = { extra = { numerator = 1, denominator = 4, x_mult = 1.5 } },
    rarity = 3, cost = 8, atlas = "gambler", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = {
            card.ability.extra.numerator,
            card.ability.extra.denominator,
            card.ability.extra.x_mult,
        } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local played = context.other_card
            if played and not played.debuff then
                if pseudorandom("lim_gamblers_pact") < (card.ability.extra.numerator / card.ability.extra.denominator) then
                    return {
                        x_mult = card.ability.extra.x_mult,
                        card = card,
                        message = localize{ type = "variable", key = "a_xmult", vars = { card.ability.extra.x_mult } }
                    }
                end
            end
        end
    end
}

----------------------------------------------
------------MOD CODE END----------------------
