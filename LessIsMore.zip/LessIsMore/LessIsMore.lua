--- STEAMODDED HEADER
--- MOD_NAME: Less Is More
--- MOD_ID: LessIsMore
--- MOD_AUTHOR: [Michael]
--- MOD_DESCRIPTION: A test pack: 11 custom Jokers exploring different scoring mechanics.
--- PREFIX: lim
--- BADGE_COLOUR: 4F6367
--- VERSION: 1.0.0

----------------------------------------------
------------MOD CODE -------------------------

----------------------------------------------------------------------
-- ATLASES (one per Joker for easy art swapping)
----------------------------------------------------------------------

local function atlas(key) SMODS.Atlas { key = key, path = "j_"..key..".png", px = 71, py = 95 } end

atlas("less_is_more")
atlas("snowball")
atlas("echo_chamber")
atlas("bookkeeper")
atlas("suited_booted")
atlas("coin_toss")
atlas("night_owl")
atlas("glass_cannon")
atlas("cardinal")
atlas("time_bomb")
atlas("gambler")

----------------------------------------------------------------------
-- 1. Less Is More  (Uncommon, $6) — +Mult per low card scored.
----------------------------------------------------------------------
SMODS.Joker {
    key = "less_is_more",
    loc_txt = {
        name = "Less Is More",
        text = {
            "This Joker gains {C:mult}+#1#{} Mult",
            "for every {C:attention}Ace{}, {C:attention}2{}, {C:attention}3{},",
            "{C:attention}4{}, or {C:attention}5{} scored",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 4, mult = 0 } },
    rarity = 2, cost = 6, atlas = "less_is_more", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local played = context.other_card
            if played and not played.debuff then
                local rank = played:get_id()
                if rank and (rank == 14 or (rank >= 2 and rank <= 5)) then
                    card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
                    return {
                        extra = { focus = card, message = localize("k_upgrade_ex") },
                        card = card, colour = G.C.MULT
                    }
                end
            end
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return {
                mult_mod = card.ability.extra.mult,
                message = localize{ type = "variable", key = "a_mult", vars = { card.ability.extra.mult } },
                colour = G.C.MULT
            }
        end
    end
}

----------------------------------------------------------------------
-- 2. Snowball  (Common, $5) — Scaling XMult per card discarded.
----------------------------------------------------------------------
SMODS.Joker {
    key = "snowball",
    loc_txt = {
        name = "Snowball",
        text = {
            "Gains {X:mult,C:white}X#1#{} Mult",
            "for every card discarded",
            "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { x_mult_gain = 0.05, x_mult = 1 } },
    rarity = 1, cost = 5, atlas = "snowball", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult_gain, card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.discard and not context.blueprint then
            card.ability.extra.x_mult = card.ability.extra.x_mult + card.ability.extra.x_mult_gain
            return {
                extra = { focus = card, message = localize("k_upgrade_ex") },
                card = card, colour = G.C.MULT
            }
        end
        if context.joker_main and card.ability.extra.x_mult > 1 then
            return {
                x_mult = card.ability.extra.x_mult,
                message = localize{ type = "variable", key = "a_xmult", vars = { card.ability.extra.x_mult } }
            }
        end
    end
}

----------------------------------------------------------------------
-- 3. Echo Chamber  (Uncommon, $7) — Retriggers leftmost scored card.
----------------------------------------------------------------------
SMODS.Joker {
    key = "echo_chamber",
    loc_txt = {
        name = "Echo Chamber",
        text = {
            "Retriggers the {C:attention}leftmost{}",
            "scored card {C:attention}#1#{} additional time"
        }
    },
    config = { extra = { repetitions = 1 } },
    rarity = 2, cost = 7, atlas = "echo_chamber", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.repetitions } }
    end,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play
                and context.scoring_hand and context.other_card == context.scoring_hand[1] then
            return {
                message = localize("k_again_ex"),
                repetitions = card.ability.extra.repetitions,
                card = card
            }
        end
    end
}

----------------------------------------------------------------------
-- 4. Bookkeeper  (Common, $4) — +1 hand size.
----------------------------------------------------------------------
SMODS.Joker {
    key = "bookkeeper",
    loc_txt = {
        name = "Bookkeeper",
        text = { "{C:attention}+#1#{} hand size" }
    },
    config = { extra = { h_size = 1 } },
    rarity = 1, cost = 4, atlas = "bookkeeper", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.h_size } }
    end,
    add_to_deck = function(self, card, from_debuff)
        G.hand:change_size(card.ability.extra.h_size)
    end,
    remove_from_deck = function(self, card, from_debuff)
        G.hand:change_size(-card.ability.extra.h_size)
    end
}

----------------------------------------------------------------------
-- 5. Suited & Booted  (Uncommon, $6) — +Chips per same-suit-as-leftmost.
----------------------------------------------------------------------
SMODS.Joker {
    key = "suited_booted",
    loc_txt = {
        name = "Suited & Booted",
        text = {
            "{C:chips}+#1#{} Chips per scored card",
            "with the same suit as the",
            "{C:attention}leftmost{} scored card"
        }
    },
    config = { extra = { chips = 30 } },
    rarity = 2, cost = 6, atlas = "suited_booted", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local played = context.other_card
            local first = context.scoring_hand and context.scoring_hand[1]
            if played and first and not played.debuff then
                local match_suit
                for _, s in ipairs({ "Spades", "Hearts", "Diamonds", "Clubs" }) do
                    if first:is_suit(s) then match_suit = s; break end
                end
                if match_suit and played:is_suit(match_suit) then
                    return { chips = card.ability.extra.chips, card = card }
                end
            end
        end
    end
}

----------------------------------------------------------------------
-- 6. Coin Toss  (Common, $5) — 50/50 +Chips or +Mult per scored card.
----------------------------------------------------------------------
SMODS.Joker {
    key = "coin_toss",
    loc_txt = {
        name = "Coin Toss",
        text = {
            "Each scored card has an even",
            "chance to give {C:chips}+#1#{} Chips",
            "or {C:mult}+#2#{} Mult"
        }
    },
    config = { extra = { chips = 30, mult = 6 } },
    rarity = 1, cost = 5, atlas = "coin_toss", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local played = context.other_card
            if played and not played.debuff then
                if pseudorandom("lim_coin_toss") < 0.5 then
                    return { chips = card.ability.extra.chips, card = card }
                else
                    return { mult = card.ability.extra.mult, card = card }
                end
            end
        end
    end
}

----------------------------------------------------------------------
-- 7. Night Owl  (Rare, $8) — XMult only on the final hand of the round.
----------------------------------------------------------------------
SMODS.Joker {
    key = "night_owl",
    loc_txt = {
        name = "Night Owl",
        text = {
            "{X:mult,C:white}X#1#{} Mult on your",
            "{C:attention}final hand{} of each round"
        }
    },
    config = { extra = { x_mult = 3 } },
    rarity = 3, cost = 8, atlas = "night_owl", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and G.GAME.current_round.hands_left == 0 then
            return {
                x_mult = card.ability.extra.x_mult,
                message = localize{ type = "variable", key = "a_xmult", vars = { card.ability.extra.x_mult } }
            }
        end
    end
}

----------------------------------------------------------------------
-- 8. Glass Cannon  (Rare, $8) — Big XMult that decays each round.
----------------------------------------------------------------------
SMODS.Joker {
    key = "glass_cannon",
    loc_txt = {
        name = "Glass Cannon",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "Loses {X:mult,C:white}X#2#{} Mult after each round",
            "{C:inactive}(min {X:mult,C:white}X1{C:inactive} Mult)"
        }
    },
    config = { extra = { x_mult = 3, decay = 0.25 } },
    rarity = 3, cost = 8, atlas = "glass_cannon", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult, card.ability.extra.decay } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and card.ability.extra.x_mult > 1 then
            return {
                x_mult = card.ability.extra.x_mult,
                message = localize{ type = "variable", key = "a_xmult", vars = { card.ability.extra.x_mult } }
            }
        end
        if context.end_of_round and not context.repetition and not context.individual and not context.blueprint then
            local new_v = math.max(1, card.ability.extra.x_mult - card.ability.extra.decay)
            if new_v ~= card.ability.extra.x_mult then
                card.ability.extra.x_mult = new_v
                return { message = "Cracked!", colour = G.C.RED, card = card }
            end
        end
    end
}

----------------------------------------------------------------------
-- 9. Cardinal  (Common, $5) — +Chips per scored Heart.
----------------------------------------------------------------------
SMODS.Joker {
    key = "cardinal",
    loc_txt = {
        name = "Cardinal",
        text = {
            "{C:chips}+#1#{} Chips for each",
            "{C:hearts}Heart{} card scored"
        }
    },
    config = { extra = { chips = 25 } },
    rarity = 1, cost = 5, atlas = "cardinal", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local played = context.other_card
            if played and not played.debuff and played:is_suit("Hearts") then
                return { chips = card.ability.extra.chips, card = card }
            end
        end
    end
}

----------------------------------------------------------------------
-- 10. Time Bomb  (Uncommon, $7) — Gains +Mult per Blind defeated.
----------------------------------------------------------------------
SMODS.Joker {
    key = "time_bomb",
    loc_txt = {
        name = "Time Bomb",
        text = {
            "Gains {C:mult}+#1#{} Mult per",
            "{C:attention}Blind{} defeated while owned",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 12, mult = 0 } },
    rarity = 2, cost = 7, atlas = "time_bomb", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.repetition and not context.individual and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
            return {
                extra = { focus = card, message = localize("k_upgrade_ex") },
                card = card, colour = G.C.MULT
            }
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return {
                mult_mod = card.ability.extra.mult,
                message = localize{ type = "variable", key = "a_mult", vars = { card.ability.extra.mult } },
                colour = G.C.MULT
            }
        end
    end
}

----------------------------------------------------------------------
-- 11. Gambler's Pact  (Rare, $8) — Per-card chance for XMult.
----------------------------------------------------------------------
SMODS.Joker {
    key = "gambler",
    loc_txt = {
        name = "Gambler's Pact",
        text = {
            "{C:green}#1# in #2#{} chance for each",
            "scored card to give {X:mult,C:white}X#3#{} Mult"
        }
    },
    config = { extra = { numerator = 1, denominator = 4, x_mult = 1.5 } },
    rarity = 3, cost = 8, atlas = "gambler", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = {
            card.ability.extra.numerator,
            card.ability.extra.denominator,
            card.ability.extra.x_mult,
        } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local played = context.other_card
            if played and not played.debuff then
                if pseudorandom("lim_gamblers_pact") < (card.ability.extra.numerator / card.ability.extra.denominator) then
                    return {
                        x_mult = card.ability.extra.x_mult,
                        card = card,
                        message = localize{ type = "variable", key = "a_xmult", vars = { card.ability.extra.x_mult } }
                    }
                end
            end
        end
    end
}

----------------------------------------------------------------------
-- AUTO-GENERATED ADDITIONAL JOKERS (139 entries)
----------------------------------------------------------------------

SMODS.Atlas { key = "hearts_chips", path = "j_hearts_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "hearts_chips",
    loc_txt = {
        name = "Heart Surgeon",
        text = {
            "{C:chips}+#1#{} Chips for each",
            "{C:hearts}Hearts{} card scored"
        }
    },
    config = { extra = { chips = 30 } },
    rarity = 1, cost = 5, atlas = "hearts_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if p:is_suit("Hearts") then
                    return { chips = card.ability.extra.chips, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "hearts_mult", path = "j_hearts_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "hearts_mult",
    loc_txt = {
        name = "Bleeding Heart",
        text = {
            "{C:mult}+#1#{} Mult for each",
            "{C:hearts}Hearts{} card scored"
        }
    },
    config = { extra = { mult = 5 } },
    rarity = 1, cost = 5, atlas = "hearts_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if p:is_suit("Hearts") then
                    return { mult = card.ability.extra.mult, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "hearts_xeach", path = "j_hearts_xeach.png", px = 71, py = 95 }
SMODS.Joker {
    key = "hearts_xeach",
    loc_txt = {
        name = "Heart Attack",
        text = {
            "{X:mult,C:white}X#1#{} Mult for each",
            "{C:hearts}Hearts{} card scored"
        }
    },
    config = { extra = { x_mult = 1.15 } },
    rarity = 2, cost = 7, atlas = "hearts_xeach", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if p:is_suit("Hearts") then
                    return { x_mult = card.ability.extra.x_mult, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "hearts_held", path = "j_hearts_held.png", px = 71, py = 95 }
SMODS.Joker {
    key = "hearts_held",
    loc_txt = {
        name = "Sweetheart",
        text = {
            "{X:mult,C:white}X#1#{} Mult if scoring",
            "hand contains a {C:hearts}Hearts{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 6, atlas = "hearts_held", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            for _, p in ipairs(context.scoring_hand or {}) do
                if p:is_suit("Hearts") then
                    return { x_mult = card.ability.extra.x_mult,
                             message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
                end
            end
        end
    end
}

SMODS.Atlas { key = "hearts_scaling", path = "j_hearts_scaling.png", px = 71, py = 95 }
SMODS.Joker {
    key = "hearts_scaling",
    loc_txt = {
        name = "Cardiac Arrest",
        text = {
            "This Joker gains {C:mult}+#1#{} Mult",
            "per {C:hearts}Hearts{} scored",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 3, mult = 0 } },
    rarity = 2, cost = 7, atlas = "hearts_scaling", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff and p:is_suit("Hearts") then
                card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
                return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
            end
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "diamonds_chips", path = "j_diamonds_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "diamonds_chips",
    loc_txt = {
        name = "Diamond Cutter",
        text = {
            "{C:chips}+#1#{} Chips for each",
            "{C:diamonds}Diamonds{} card scored"
        }
    },
    config = { extra = { chips = 30 } },
    rarity = 1, cost = 5, atlas = "diamonds_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if p:is_suit("Diamonds") then
                    return { chips = card.ability.extra.chips, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "diamonds_mult", path = "j_diamonds_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "diamonds_mult",
    loc_txt = {
        name = "Brilliant Cut",
        text = {
            "{C:mult}+#1#{} Mult for each",
            "{C:diamonds}Diamonds{} card scored"
        }
    },
    config = { extra = { mult = 5 } },
    rarity = 1, cost = 5, atlas = "diamonds_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if p:is_suit("Diamonds") then
                    return { mult = card.ability.extra.mult, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "diamonds_xeach", path = "j_diamonds_xeach.png", px = 71, py = 95 }
SMODS.Joker {
    key = "diamonds_xeach",
    loc_txt = {
        name = "Cubic Zirconia",
        text = {
            "{X:mult,C:white}X#1#{} Mult for each",
            "{C:diamonds}Diamonds{} card scored"
        }
    },
    config = { extra = { x_mult = 1.15 } },
    rarity = 2, cost = 7, atlas = "diamonds_xeach", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if p:is_suit("Diamonds") then
                    return { x_mult = card.ability.extra.x_mult, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "diamonds_held", path = "j_diamonds_held.png", px = 71, py = 95 }
SMODS.Joker {
    key = "diamonds_held",
    loc_txt = {
        name = "Solitaire",
        text = {
            "{X:mult,C:white}X#1#{} Mult if scoring",
            "hand contains a {C:diamonds}Diamonds{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 6, atlas = "diamonds_held", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            for _, p in ipairs(context.scoring_hand or {}) do
                if p:is_suit("Diamonds") then
                    return { x_mult = card.ability.extra.x_mult,
                             message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
                end
            end
        end
    end
}

SMODS.Atlas { key = "diamonds_scaling", path = "j_diamonds_scaling.png", px = 71, py = 95 }
SMODS.Joker {
    key = "diamonds_scaling",
    loc_txt = {
        name = "Carbonado",
        text = {
            "This Joker gains {C:mult}+#1#{} Mult",
            "per {C:diamonds}Diamonds{} scored",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 3, mult = 0 } },
    rarity = 2, cost = 7, atlas = "diamonds_scaling", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff and p:is_suit("Diamonds") then
                card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
                return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
            end
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "clubs_chips", path = "j_clubs_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "clubs_chips",
    loc_txt = {
        name = "Country Club",
        text = {
            "{C:chips}+#1#{} Chips for each",
            "{C:clubs}Clubs{} card scored"
        }
    },
    config = { extra = { chips = 30 } },
    rarity = 1, cost = 5, atlas = "clubs_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if p:is_suit("Clubs") then
                    return { chips = card.ability.extra.chips, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "clubs_mult", path = "j_clubs_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "clubs_mult",
    loc_txt = {
        name = "Nightclub",
        text = {
            "{C:mult}+#1#{} Mult for each",
            "{C:clubs}Clubs{} card scored"
        }
    },
    config = { extra = { mult = 5 } },
    rarity = 1, cost = 5, atlas = "clubs_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if p:is_suit("Clubs") then
                    return { mult = card.ability.extra.mult, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "clubs_xeach", path = "j_clubs_xeach.png", px = 71, py = 95 }
SMODS.Joker {
    key = "clubs_xeach",
    loc_txt = {
        name = "Club Sandwich",
        text = {
            "{X:mult,C:white}X#1#{} Mult for each",
            "{C:clubs}Clubs{} card scored"
        }
    },
    config = { extra = { x_mult = 1.15 } },
    rarity = 2, cost = 7, atlas = "clubs_xeach", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if p:is_suit("Clubs") then
                    return { x_mult = card.ability.extra.x_mult, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "clubs_held", path = "j_clubs_held.png", px = 71, py = 95 }
SMODS.Joker {
    key = "clubs_held",
    loc_txt = {
        name = "Bludgeon",
        text = {
            "{X:mult,C:white}X#1#{} Mult if scoring",
            "hand contains a {C:clubs}Clubs{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 6, atlas = "clubs_held", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            for _, p in ipairs(context.scoring_hand or {}) do
                if p:is_suit("Clubs") then
                    return { x_mult = card.ability.extra.x_mult,
                             message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
                end
            end
        end
    end
}

SMODS.Atlas { key = "clubs_scaling", path = "j_clubs_scaling.png", px = 71, py = 95 }
SMODS.Joker {
    key = "clubs_scaling",
    loc_txt = {
        name = "Cudgel",
        text = {
            "This Joker gains {C:mult}+#1#{} Mult",
            "per {C:clubs}Clubs{} scored",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 3, mult = 0 } },
    rarity = 2, cost = 7, atlas = "clubs_scaling", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff and p:is_suit("Clubs") then
                card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
                return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
            end
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "spades_chips", path = "j_spades_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "spades_chips",
    loc_txt = {
        name = "Pitchfork",
        text = {
            "{C:chips}+#1#{} Chips for each",
            "{C:spades}Spades{} card scored"
        }
    },
    config = { extra = { chips = 30 } },
    rarity = 1, cost = 5, atlas = "spades_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if p:is_suit("Spades") then
                    return { chips = card.ability.extra.chips, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "spades_mult", path = "j_spades_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "spades_mult",
    loc_txt = {
        name = "Spadesman",
        text = {
            "{C:mult}+#1#{} Mult for each",
            "{C:spades}Spades{} card scored"
        }
    },
    config = { extra = { mult = 5 } },
    rarity = 1, cost = 5, atlas = "spades_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if p:is_suit("Spades") then
                    return { mult = card.ability.extra.mult, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "spades_xeach", path = "j_spades_xeach.png", px = 71, py = 95 }
SMODS.Joker {
    key = "spades_xeach",
    loc_txt = {
        name = "Grave Digger",
        text = {
            "{X:mult,C:white}X#1#{} Mult for each",
            "{C:spades}Spades{} card scored"
        }
    },
    config = { extra = { x_mult = 1.15 } },
    rarity = 2, cost = 7, atlas = "spades_xeach", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if p:is_suit("Spades") then
                    return { x_mult = card.ability.extra.x_mult, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "spades_held", path = "j_spades_held.png", px = 71, py = 95 }
SMODS.Joker {
    key = "spades_held",
    loc_txt = {
        name = "Pikeman",
        text = {
            "{X:mult,C:white}X#1#{} Mult if scoring",
            "hand contains a {C:spades}Spades{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 6, atlas = "spades_held", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            for _, p in ipairs(context.scoring_hand or {}) do
                if p:is_suit("Spades") then
                    return { x_mult = card.ability.extra.x_mult,
                             message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
                end
            end
        end
    end
}

SMODS.Atlas { key = "spades_scaling", path = "j_spades_scaling.png", px = 71, py = 95 }
SMODS.Joker {
    key = "spades_scaling",
    loc_txt = {
        name = "Black Death",
        text = {
            "This Joker gains {C:mult}+#1#{} Mult",
            "per {C:spades}Spades{} scored",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 3, mult = 0 } },
    rarity = 2, cost = 7, atlas = "spades_scaling", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff and p:is_suit("Spades") then
                card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
                return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
            end
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "ht_pair_chips", path = "j_ht_pair_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_pair_chips",
    loc_txt = {
        name = "Two's Company",
        text = {
            "{C:chips}+#1#{} Chips if played",
            "hand contains a {C:attention}Pair{}"
        }
    },
    config = { extra = { chips = 60 } },
    rarity = 1, cost = 5, atlas = "ht_pair_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Pair"] or {}) then
            return { chips_mod = card.ability.extra.chips,
                     message = localize{ type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } } }
        end
    end
}

SMODS.Atlas { key = "ht_pair_mult", path = "j_ht_pair_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_pair_mult",
    loc_txt = {
        name = "Pair Bonded",
        text = {
            "{C:mult}+#1#{} Mult if played",
            "hand contains a {C:attention}Pair{}"
        }
    },
    config = { extra = { mult = 8 } },
    rarity = 1, cost = 5, atlas = "ht_pair_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Pair"] or {}) then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "ht_pair_xmult", path = "j_ht_pair_xmult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_pair_xmult",
    loc_txt = {
        name = "Pair Plus",
        text = {
            "{X:mult,C:white}X#1#{} Mult if played",
            "hand contains a {C:attention}Pair{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "ht_pair_xmult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Pair"] or {}) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "ht_two_pair_chips", path = "j_ht_two_pair_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_two_pair_chips",
    loc_txt = {
        name = "Doublemint",
        text = {
            "{C:chips}+#1#{} Chips if played",
            "hand contains a {C:attention}Two Pair{}"
        }
    },
    config = { extra = { chips = 60 } },
    rarity = 1, cost = 5, atlas = "ht_two_pair_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Two Pair"] or {}) then
            return { chips_mod = card.ability.extra.chips,
                     message = localize{ type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } } }
        end
    end
}

SMODS.Atlas { key = "ht_two_pair_mult", path = "j_ht_two_pair_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_two_pair_mult",
    loc_txt = {
        name = "Twin Peaks",
        text = {
            "{C:mult}+#1#{} Mult if played",
            "hand contains a {C:attention}Two Pair{}"
        }
    },
    config = { extra = { mult = 8 } },
    rarity = 1, cost = 5, atlas = "ht_two_pair_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Two Pair"] or {}) then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "ht_two_pair_xmult", path = "j_ht_two_pair_xmult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_two_pair_xmult",
    loc_txt = {
        name = "Pair of Pairs",
        text = {
            "{X:mult,C:white}X#1#{} Mult if played",
            "hand contains a {C:attention}Two Pair{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "ht_two_pair_xmult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Two Pair"] or {}) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "ht_three_of_a_kind_chips", path = "j_ht_three_of_a_kind_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_three_of_a_kind_chips",
    loc_txt = {
        name = "Triplets",
        text = {
            "{C:chips}+#1#{} Chips if played",
            "hand contains a {C:attention}Three of a Kind{}"
        }
    },
    config = { extra = { chips = 60 } },
    rarity = 1, cost = 5, atlas = "ht_three_of_a_kind_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Three of a Kind"] or {}) then
            return { chips_mod = card.ability.extra.chips,
                     message = localize{ type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } } }
        end
    end
}

SMODS.Atlas { key = "ht_three_of_a_kind_mult", path = "j_ht_three_of_a_kind_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_three_of_a_kind_mult",
    loc_txt = {
        name = "Trio Sonata",
        text = {
            "{C:mult}+#1#{} Mult if played",
            "hand contains a {C:attention}Three of a Kind{}"
        }
    },
    config = { extra = { mult = 8 } },
    rarity = 1, cost = 5, atlas = "ht_three_of_a_kind_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Three of a Kind"] or {}) then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "ht_three_of_a_kind_xmult", path = "j_ht_three_of_a_kind_xmult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_three_of_a_kind_xmult",
    loc_txt = {
        name = "Three Wise Men",
        text = {
            "{X:mult,C:white}X#1#{} Mult if played",
            "hand contains a {C:attention}Three of a Kind{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "ht_three_of_a_kind_xmult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Three of a Kind"] or {}) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "ht_straight_chips", path = "j_ht_straight_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_straight_chips",
    loc_txt = {
        name = "Straightforward",
        text = {
            "{C:chips}+#1#{} Chips if played",
            "hand contains a {C:attention}Straight{}"
        }
    },
    config = { extra = { chips = 60 } },
    rarity = 1, cost = 5, atlas = "ht_straight_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Straight"] or {}) then
            return { chips_mod = card.ability.extra.chips,
                     message = localize{ type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } } }
        end
    end
}

SMODS.Atlas { key = "ht_straight_mult", path = "j_ht_straight_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_straight_mult",
    loc_txt = {
        name = "Linear Algebra",
        text = {
            "{C:mult}+#1#{} Mult if played",
            "hand contains a {C:attention}Straight{}"
        }
    },
    config = { extra = { mult = 8 } },
    rarity = 1, cost = 5, atlas = "ht_straight_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Straight"] or {}) then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "ht_straight_xmult", path = "j_ht_straight_xmult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_straight_xmult",
    loc_txt = {
        name = "Bee Line",
        text = {
            "{X:mult,C:white}X#1#{} Mult if played",
            "hand contains a {C:attention}Straight{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "ht_straight_xmult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Straight"] or {}) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "ht_flush_chips", path = "j_ht_flush_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_flush_chips",
    loc_txt = {
        name = "Color Theory",
        text = {
            "{C:chips}+#1#{} Chips if played",
            "hand contains a {C:attention}Flush{}"
        }
    },
    config = { extra = { chips = 60 } },
    rarity = 1, cost = 5, atlas = "ht_flush_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Flush"] or {}) then
            return { chips_mod = card.ability.extra.chips,
                     message = localize{ type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } } }
        end
    end
}

SMODS.Atlas { key = "ht_flush_mult", path = "j_ht_flush_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_flush_mult",
    loc_txt = {
        name = "Hue and Cry",
        text = {
            "{C:mult}+#1#{} Mult if played",
            "hand contains a {C:attention}Flush{}"
        }
    },
    config = { extra = { mult = 8 } },
    rarity = 1, cost = 5, atlas = "ht_flush_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Flush"] or {}) then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "ht_flush_xmult", path = "j_ht_flush_xmult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_flush_xmult",
    loc_txt = {
        name = "Monochrome",
        text = {
            "{X:mult,C:white}X#1#{} Mult if played",
            "hand contains a {C:attention}Flush{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "ht_flush_xmult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Flush"] or {}) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "ht_full_house_chips", path = "j_ht_full_house_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_full_house_chips",
    loc_txt = {
        name = "Family Reunion",
        text = {
            "{C:chips}+#1#{} Chips if played",
            "hand contains a {C:attention}Full House{}"
        }
    },
    config = { extra = { chips = 60 } },
    rarity = 1, cost = 5, atlas = "ht_full_house_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Full House"] or {}) then
            return { chips_mod = card.ability.extra.chips,
                     message = localize{ type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } } }
        end
    end
}

SMODS.Atlas { key = "ht_full_house_mult", path = "j_ht_full_house_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_full_house_mult",
    loc_txt = {
        name = "Open House",
        text = {
            "{C:mult}+#1#{} Mult if played",
            "hand contains a {C:attention}Full House{}"
        }
    },
    config = { extra = { mult = 8 } },
    rarity = 1, cost = 5, atlas = "ht_full_house_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Full House"] or {}) then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "ht_full_house_xmult", path = "j_ht_full_house_xmult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_full_house_xmult",
    loc_txt = {
        name = "Full Boat",
        text = {
            "{X:mult,C:white}X#1#{} Mult if played",
            "hand contains a {C:attention}Full House{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "ht_full_house_xmult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Full House"] or {}) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "ht_four_of_a_kind_chips", path = "j_ht_four_of_a_kind_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_four_of_a_kind_chips",
    loc_txt = {
        name = "Quartermaster",
        text = {
            "{C:chips}+#1#{} Chips if played",
            "hand contains a {C:attention}Four of a Kind{}"
        }
    },
    config = { extra = { chips = 60 } },
    rarity = 1, cost = 5, atlas = "ht_four_of_a_kind_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Four of a Kind"] or {}) then
            return { chips_mod = card.ability.extra.chips,
                     message = localize{ type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } } }
        end
    end
}

SMODS.Atlas { key = "ht_four_of_a_kind_mult", path = "j_ht_four_of_a_kind_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_four_of_a_kind_mult",
    loc_txt = {
        name = "Quartet",
        text = {
            "{C:mult}+#1#{} Mult if played",
            "hand contains a {C:attention}Four of a Kind{}"
        }
    },
    config = { extra = { mult = 8 } },
    rarity = 1, cost = 5, atlas = "ht_four_of_a_kind_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Four of a Kind"] or {}) then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "ht_four_of_a_kind_xmult", path = "j_ht_four_of_a_kind_xmult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_four_of_a_kind_xmult",
    loc_txt = {
        name = "Four Horsemen",
        text = {
            "{X:mult,C:white}X#1#{} Mult if played",
            "hand contains a {C:attention}Four of a Kind{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "ht_four_of_a_kind_xmult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Four of a Kind"] or {}) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "ht_straight_flush_chips", path = "j_ht_straight_flush_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_straight_flush_chips",
    loc_txt = {
        name = "Royal Road",
        text = {
            "{C:chips}+#1#{} Chips if played",
            "hand contains a {C:attention}Straight Flush{}"
        }
    },
    config = { extra = { chips = 60 } },
    rarity = 1, cost = 5, atlas = "ht_straight_flush_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Straight Flush"] or {}) then
            return { chips_mod = card.ability.extra.chips,
                     message = localize{ type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } } }
        end
    end
}

SMODS.Atlas { key = "ht_straight_flush_mult", path = "j_ht_straight_flush_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_straight_flush_mult",
    loc_txt = {
        name = "Color Order",
        text = {
            "{C:mult}+#1#{} Mult if played",
            "hand contains a {C:attention}Straight Flush{}"
        }
    },
    config = { extra = { mult = 8 } },
    rarity = 1, cost = 5, atlas = "ht_straight_flush_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Straight Flush"] or {}) then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "ht_straight_flush_xmult", path = "j_ht_straight_flush_xmult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_straight_flush_xmult",
    loc_txt = {
        name = "Painted Line",
        text = {
            "{X:mult,C:white}X#1#{} Mult if played",
            "hand contains a {C:attention}Straight Flush{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "ht_straight_flush_xmult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Straight Flush"] or {}) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "ht_five_of_a_kind_chips", path = "j_ht_five_of_a_kind_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_five_of_a_kind_chips",
    loc_txt = {
        name = "Quintessence",
        text = {
            "{C:chips}+#1#{} Chips if played",
            "hand contains a {C:attention}Five of a Kind{}"
        }
    },
    config = { extra = { chips = 60 } },
    rarity = 1, cost = 5, atlas = "ht_five_of_a_kind_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Five of a Kind"] or {}) then
            return { chips_mod = card.ability.extra.chips,
                     message = localize{ type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } } }
        end
    end
}

SMODS.Atlas { key = "ht_five_of_a_kind_mult", path = "j_ht_five_of_a_kind_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_five_of_a_kind_mult",
    loc_txt = {
        name = "Five Alive",
        text = {
            "{C:mult}+#1#{} Mult if played",
            "hand contains a {C:attention}Five of a Kind{}"
        }
    },
    config = { extra = { mult = 8 } },
    rarity = 1, cost = 5, atlas = "ht_five_of_a_kind_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Five of a Kind"] or {}) then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "ht_five_of_a_kind_xmult", path = "j_ht_five_of_a_kind_xmult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_five_of_a_kind_xmult",
    loc_txt = {
        name = "Pentahedron",
        text = {
            "{X:mult,C:white}X#1#{} Mult if played",
            "hand contains a {C:attention}Five of a Kind{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "ht_five_of_a_kind_xmult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Five of a Kind"] or {}) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "ht_flush_house_chips", path = "j_ht_flush_house_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_flush_house_chips",
    loc_txt = {
        name = "Mansion",
        text = {
            "{C:chips}+#1#{} Chips if played",
            "hand contains a {C:attention}Flush House{}"
        }
    },
    config = { extra = { chips = 60 } },
    rarity = 1, cost = 5, atlas = "ht_flush_house_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Flush House"] or {}) then
            return { chips_mod = card.ability.extra.chips,
                     message = localize{ type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } } }
        end
    end
}

SMODS.Atlas { key = "ht_flush_house_mult", path = "j_ht_flush_house_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_flush_house_mult",
    loc_txt = {
        name = "Painted House",
        text = {
            "{C:mult}+#1#{} Mult if played",
            "hand contains a {C:attention}Flush House{}"
        }
    },
    config = { extra = { mult = 8 } },
    rarity = 1, cost = 5, atlas = "ht_flush_house_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Flush House"] or {}) then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "ht_flush_house_xmult", path = "j_ht_flush_house_xmult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "ht_flush_house_xmult",
    loc_txt = {
        name = "Color Mansion",
        text = {
            "{X:mult,C:white}X#1#{} Mult if played",
            "hand contains a {C:attention}Flush House{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "ht_flush_house_xmult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and next(context.poker_hands["Flush House"] or {}) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "rk_face_chips", path = "j_rk_face_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rk_face_chips",
    loc_txt = {
        name = "Face Off",
        text = {
            "{C:chips}+#1#{} Chips for each",
            "{C:attention}face card{} scored"
        }
    },
    config = { extra = { chips = 25 } },
    rarity = 1, cost = 5, atlas = "rk_face_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                local r = p:get_id()
                if r and ((r >= 11 and r <= 13)) then
                    return { chips = card.ability.extra.chips, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "rk_face_mult", path = "j_rk_face_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rk_face_mult",
    loc_txt = {
        name = "Face Value",
        text = {
            "{C:mult}+#1#{} Mult for each",
            "{C:attention}face card{} scored"
        }
    },
    config = { extra = { mult = 5 } },
    rarity = 1, cost = 5, atlas = "rk_face_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                local r = p:get_id()
                if r and ((r >= 11 and r <= 13)) then
                    return { mult = card.ability.extra.mult, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "rk_face_scaling", path = "j_rk_face_scaling.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rk_face_scaling",
    loc_txt = {
        name = "Face Time",
        text = {
            "This Joker gains {C:mult}+#1#{} Mult",
            "per {C:attention}face card{} scored",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 3, mult = 0 } },
    rarity = 2, cost = 7, atlas = "rk_face_scaling", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                local r = p:get_id()
                if r and ((r >= 11 and r <= 13)) then
                    card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
                    return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
                end
            end
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "rk_six_chips", path = "j_rk_six_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rk_six_chips",
    loc_txt = {
        name = "Devil's Six",
        text = {
            "{C:chips}+#1#{} Chips for each",
            "{C:attention}6{} scored"
        }
    },
    config = { extra = { chips = 25 } },
    rarity = 1, cost = 5, atlas = "rk_six_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                local r = p:get_id()
                if r and (r == 6) then
                    return { chips = card.ability.extra.chips, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "rk_six_mult", path = "j_rk_six_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rk_six_mult",
    loc_txt = {
        name = "Six Appeal",
        text = {
            "{C:mult}+#1#{} Mult for each",
            "{C:attention}6{} scored"
        }
    },
    config = { extra = { mult = 5 } },
    rarity = 1, cost = 5, atlas = "rk_six_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                local r = p:get_id()
                if r and (r == 6) then
                    return { mult = card.ability.extra.mult, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "rk_six_scaling", path = "j_rk_six_scaling.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rk_six_scaling",
    loc_txt = {
        name = "Sixfold Path",
        text = {
            "This Joker gains {C:mult}+#1#{} Mult",
            "per {C:attention}6{} scored",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 3, mult = 0 } },
    rarity = 2, cost = 7, atlas = "rk_six_scaling", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                local r = p:get_id()
                if r and (r == 6) then
                    card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
                    return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
                end
            end
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "rk_seven_chips", path = "j_rk_seven_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rk_seven_chips",
    loc_txt = {
        name = "Lucky Seven",
        text = {
            "{C:chips}+#1#{} Chips for each",
            "{C:attention}7{} scored"
        }
    },
    config = { extra = { chips = 25 } },
    rarity = 1, cost = 5, atlas = "rk_seven_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                local r = p:get_id()
                if r and (r == 7) then
                    return { chips = card.ability.extra.chips, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "rk_seven_mult", path = "j_rk_seven_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rk_seven_mult",
    loc_txt = {
        name = "Seven Up",
        text = {
            "{C:mult}+#1#{} Mult for each",
            "{C:attention}7{} scored"
        }
    },
    config = { extra = { mult = 5 } },
    rarity = 1, cost = 5, atlas = "rk_seven_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                local r = p:get_id()
                if r and (r == 7) then
                    return { mult = card.ability.extra.mult, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "rk_seven_scaling", path = "j_rk_seven_scaling.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rk_seven_scaling",
    loc_txt = {
        name = "Magnificent Seven",
        text = {
            "This Joker gains {C:mult}+#1#{} Mult",
            "per {C:attention}7{} scored",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 3, mult = 0 } },
    rarity = 2, cost = 7, atlas = "rk_seven_scaling", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                local r = p:get_id()
                if r and (r == 7) then
                    card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
                    return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
                end
            end
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "rk_eight_chips", path = "j_rk_eight_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rk_eight_chips",
    loc_txt = {
        name = "Crazy Eight",
        text = {
            "{C:chips}+#1#{} Chips for each",
            "{C:attention}8{} scored"
        }
    },
    config = { extra = { chips = 25 } },
    rarity = 1, cost = 5, atlas = "rk_eight_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                local r = p:get_id()
                if r and (r == 8) then
                    return { chips = card.ability.extra.chips, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "rk_eight_mult", path = "j_rk_eight_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rk_eight_mult",
    loc_txt = {
        name = "Behind the 8",
        text = {
            "{C:mult}+#1#{} Mult for each",
            "{C:attention}8{} scored"
        }
    },
    config = { extra = { mult = 5 } },
    rarity = 1, cost = 5, atlas = "rk_eight_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                local r = p:get_id()
                if r and (r == 8) then
                    return { mult = card.ability.extra.mult, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "rk_eight_scaling", path = "j_rk_eight_scaling.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rk_eight_scaling",
    loc_txt = {
        name = "Eight Track",
        text = {
            "This Joker gains {C:mult}+#1#{} Mult",
            "per {C:attention}8{} scored",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 3, mult = 0 } },
    rarity = 2, cost = 7, atlas = "rk_eight_scaling", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                local r = p:get_id()
                if r and (r == 8) then
                    card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
                    return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
                end
            end
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "sc_per_discard_mult", path = "j_sc_per_discard_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sc_per_discard_mult",
    loc_txt = {
        name = "Avalanche",
        text = {
            "Gains {C:mult}+#1#{} Mult",
            "for every card discarded",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 1, mult = 0 } },
    rarity = 2, cost = 7, atlas = "sc_per_discard_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.discard and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "sc_per_discard_chips", path = "j_sc_per_discard_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sc_per_discard_chips",
    loc_txt = {
        name = "Snowdrift",
        text = {
            "Gains {C:mult}+#1#{} Mult",
            "for every card discarded",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 5, mult = 0 } },
    rarity = 2, cost = 7, atlas = "sc_per_discard_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.discard and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "sc_per_round_mult", path = "j_sc_per_round_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sc_per_round_mult",
    loc_txt = {
        name = "Slow Burn",
        text = {
            "Gains {C:mult}+#1#{} Mult",
            "after every round",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 6, mult = 0 } },
    rarity = 2, cost = 7, atlas = "sc_per_round_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.repetition and not context.individual and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "sc_per_round_chips", path = "j_sc_per_round_chips.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sc_per_round_chips",
    loc_txt = {
        name = "Compound Interest",
        text = {
            "Gains {C:mult}+#1#{} Mult",
            "after every round",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 30, mult = 0 } },
    rarity = 2, cost = 7, atlas = "sc_per_round_chips", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.repetition and not context.individual and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "sc_per_blind_mult", path = "j_sc_per_blind_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sc_per_blind_mult",
    loc_txt = {
        name = "Cumulus",
        text = {
            "Gains {C:mult}+#1#{} Mult",
            "per Blind defeated",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 8, mult = 0 } },
    rarity = 2, cost = 7, atlas = "sc_per_blind_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.repetition and not context.individual and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "sc_per_skip_mult", path = "j_sc_per_skip_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sc_per_skip_mult",
    loc_txt = {
        name = "Coward",
        text = {
            "Gains {C:mult}+#1#{} Mult",
            "per Blind skipped",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 10, mult = 0 } },
    rarity = 2, cost = 7, atlas = "sc_per_skip_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.skip_blind and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "sc_per_shop_mult", path = "j_sc_per_shop_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sc_per_shop_mult",
    loc_txt = {
        name = "Window Shopper",
        text = {
            "Gains {C:mult}+#1#{} Mult",
            "per shop visited",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 5, mult = 0 } },
    rarity = 2, cost = 7, atlas = "sc_per_shop_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.ending_shop and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "sc_per_consumable_mult", path = "j_sc_per_consumable_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sc_per_consumable_mult",
    loc_txt = {
        name = "Sage",
        text = {
            "Gains {C:mult}+#1#{} Mult",
            "per consumable used",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 5, mult = 0 } },
    rarity = 2, cost = 7, atlas = "sc_per_consumable_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.using_consumeable and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "sc_per_card_destroyed", path = "j_sc_per_card_destroyed.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sc_per_card_destroyed",
    loc_txt = {
        name = "Phoenix",
        text = {
            "Gains {C:mult}+#1#{} Mult",
            "per card destroyed",
            "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { mult_gain = 8, mult = 0 } },
    rarity = 2, cost = 7, atlas = "sc_per_card_destroyed", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult_gain, card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.remove_playing_cards and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "sx_xpd_mult", path = "j_sx_xpd_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sx_xpd_mult",
    loc_txt = {
        name = "Glacier",
        text = {
            "Gains {X:mult,C:white}X#1#{} Mult",
            "for every card discarded",
            "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { x_gain = 0.02, x_mult = 1 } },
    rarity = 3, cost = 8, atlas = "sx_xpd_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_gain, card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.discard and not context.blueprint then
            card.ability.extra.x_mult = card.ability.extra.x_mult + card.ability.extra.x_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.x_mult > 1 then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "sx_xpr_mult", path = "j_sx_xpr_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sx_xpr_mult",
    loc_txt = {
        name = "Geological",
        text = {
            "Gains {X:mult,C:white}X#1#{} Mult",
            "after every round",
            "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { x_gain = 0.05, x_mult = 1 } },
    rarity = 3, cost = 8, atlas = "sx_xpr_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_gain, card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.repetition and not context.individual and not context.blueprint then
            card.ability.extra.x_mult = card.ability.extra.x_mult + card.ability.extra.x_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.x_mult > 1 then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "sx_xpb_mult", path = "j_sx_xpb_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sx_xpb_mult",
    loc_txt = {
        name = "Tectonic",
        text = {
            "Gains {X:mult,C:white}X#1#{} Mult",
            "per Blind defeated",
            "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { x_gain = 0.08, x_mult = 1 } },
    rarity = 3, cost = 8, atlas = "sx_xpb_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_gain, card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.repetition and not context.individual and not context.blueprint then
            card.ability.extra.x_mult = card.ability.extra.x_mult + card.ability.extra.x_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.x_mult > 1 then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "sx_xpc_mult", path = "j_sx_xpc_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sx_xpc_mult",
    loc_txt = {
        name = "Mystic",
        text = {
            "Gains {X:mult,C:white}X#1#{} Mult",
            "per consumable used",
            "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { x_gain = 0.05, x_mult = 1 } },
    rarity = 3, cost = 8, atlas = "sx_xpc_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_gain, card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.using_consumeable and not context.blueprint then
            card.ability.extra.x_mult = card.ability.extra.x_mult + card.ability.extra.x_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.x_mult > 1 then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "sx_xpd_chip", path = "j_sx_xpd_chip.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sx_xpd_chip",
    loc_txt = {
        name = "Avalanche II",
        text = {
            "Gains {X:mult,C:white}X#1#{} Mult",
            "after every card discarded",
            "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { x_gain = 0.02, x_mult = 1 } },
    rarity = 3, cost = 8, atlas = "sx_xpd_chip", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_gain, card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.discard and not context.blueprint then
            card.ability.extra.x_mult = card.ability.extra.x_mult + card.ability.extra.x_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.x_mult > 1 then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "sx_xph_mult", path = "j_sx_xph_mult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "sx_xph_mult",
    loc_txt = {
        name = "Wear & Tear",
        text = {
            "Gains {X:mult,C:white}X#1#{} Mult",
            "per hand played",
            "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)"
        }
    },
    config = { extra = { x_gain = 0.04, x_mult = 1 } },
    rarity = 3, cost = 8, atlas = "sx_xph_mult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_gain, card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.before and not context.blueprint and not context.blueprint then
            card.ability.extra.x_mult = card.ability.extra.x_mult + card.ability.extra.x_gain
            return { extra = { focus = card, message = localize('k_upgrade_ex') }, card = card, colour = G.C.MULT }
        end
        if context.joker_main and card.ability.extra.x_mult > 1 then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "prob_0", path = "j_prob_0.png", px = 71, py = 95 }
SMODS.Joker {
    key = "prob_0",
    loc_txt = {
        name = "Heads",
        text = {
            "{C:green}#1# in #2#{} chance for",
            "each scored card to give {C:chips}+#3#{} Chips"
        }
    },
    config = { extra = { num = 1, den = 2, amt = 30 } },
    rarity = 2, cost = 6, atlas = "prob_0", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.num, card.ability.extra.den, card.ability.extra.amt } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                if pseudorandom('lim_p2c') < (card.ability.extra.num / card.ability.extra.den) then
                    return { chips = card.ability.extra.amt, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "prob_1", path = "j_prob_1.png", px = 71, py = 95 }
SMODS.Joker {
    key = "prob_1",
    loc_txt = {
        name = "Triple Threat",
        text = {
            "{C:green}#1# in #2#{} chance for",
            "each scored card to give {C:chips}+#3#{} Chips"
        }
    },
    config = { extra = { num = 1, den = 3, amt = 60 } },
    rarity = 2, cost = 6, atlas = "prob_1", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.num, card.ability.extra.den, card.ability.extra.amt } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                if pseudorandom('lim_p3c') < (card.ability.extra.num / card.ability.extra.den) then
                    return { chips = card.ability.extra.amt, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "prob_2", path = "j_prob_2.png", px = 71, py = 95 }
SMODS.Joker {
    key = "prob_2",
    loc_txt = {
        name = "Quartile",
        text = {
            "{C:green}#1# in #2#{} chance for",
            "each scored card to give {C:chips}+#3#{} Chips"
        }
    },
    config = { extra = { num = 1, den = 4, amt = 90 } },
    rarity = 2, cost = 6, atlas = "prob_2", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.num, card.ability.extra.den, card.ability.extra.amt } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                if pseudorandom('lim_p4c') < (card.ability.extra.num / card.ability.extra.den) then
                    return { chips = card.ability.extra.amt, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "prob_3", path = "j_prob_3.png", px = 71, py = 95 }
SMODS.Joker {
    key = "prob_3",
    loc_txt = {
        name = "Tails",
        text = {
            "{C:green}#1# in #2#{} chance for",
            "each scored card to give {C:mult}+#3#{} Mult"
        }
    },
    config = { extra = { num = 1, den = 2, amt = 6 } },
    rarity = 2, cost = 6, atlas = "prob_3", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.num, card.ability.extra.den, card.ability.extra.amt } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                if pseudorandom('lim_p2m') < (card.ability.extra.num / card.ability.extra.den) then
                    return { mult = card.ability.extra.amt, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "prob_4", path = "j_prob_4.png", px = 71, py = 95 }
SMODS.Joker {
    key = "prob_4",
    loc_txt = {
        name = "Trifecta",
        text = {
            "{C:green}#1# in #2#{} chance for",
            "each scored card to give {C:mult}+#3#{} Mult"
        }
    },
    config = { extra = { num = 1, den = 3, amt = 10 } },
    rarity = 2, cost = 6, atlas = "prob_4", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.num, card.ability.extra.den, card.ability.extra.amt } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                if pseudorandom('lim_p3m') < (card.ability.extra.num / card.ability.extra.den) then
                    return { mult = card.ability.extra.amt, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "prob_5", path = "j_prob_5.png", px = 71, py = 95 }
SMODS.Joker {
    key = "prob_5",
    loc_txt = {
        name = "Long Odds",
        text = {
            "{C:green}#1# in #2#{} chance for",
            "each scored card to give {C:mult}+#3#{} Mult"
        }
    },
    config = { extra = { num = 1, den = 4, amt = 16 } },
    rarity = 2, cost = 6, atlas = "prob_5", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.num, card.ability.extra.den, card.ability.extra.amt } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                if pseudorandom('lim_p4m') < (card.ability.extra.num / card.ability.extra.den) then
                    return { mult = card.ability.extra.amt, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "prob_6", path = "j_prob_6.png", px = 71, py = 95 }
SMODS.Joker {
    key = "prob_6",
    loc_txt = {
        name = "Casino Royale",
        text = {
            "{C:green}#1# in #2#{} chance for",
            "each scored card to give {X:mult,C:white}X#3#{} Mult"
        }
    },
    config = { extra = { num = 1, den = 3, amt = 1.5 } },
    rarity = 3, cost = 8, atlas = "prob_6", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.num, card.ability.extra.den, card.ability.extra.amt } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                if pseudorandom('lim_p3x') < (card.ability.extra.num / card.ability.extra.den) then
                    return { x_mult = card.ability.extra.amt, card = card, message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.amt } } }
                end
            end
        end
    end
}

SMODS.Atlas { key = "prob_7", path = "j_prob_7.png", px = 71, py = 95 }
SMODS.Joker {
    key = "prob_7",
    loc_txt = {
        name = "House Always",
        text = {
            "{C:green}#1# in #2#{} chance for",
            "each scored card to give {X:mult,C:white}X#3#{} Mult"
        }
    },
    config = { extra = { num = 1, den = 4, amt = 2 } },
    rarity = 3, cost = 8, atlas = "prob_7", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.num, card.ability.extra.den, card.ability.extra.amt } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                if pseudorandom('lim_p4x') < (card.ability.extra.num / card.ability.extra.den) then
                    return { x_mult = card.ability.extra.amt, card = card, message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.amt } } }
                end
            end
        end
    end
}

SMODS.Atlas { key = "prob_8", path = "j_prob_8.png", px = 71, py = 95 }
SMODS.Joker {
    key = "prob_8",
    loc_txt = {
        name = "Cold Streak",
        text = {
            "{C:green}#1# in #2#{} chance for",
            "each scored card to give {X:mult,C:white}X#3#{} Mult"
        }
    },
    config = { extra = { num = 1, den = 6, amt = 3 } },
    rarity = 3, cost = 8, atlas = "prob_8", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.num, card.ability.extra.den, card.ability.extra.amt } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                if pseudorandom('lim_p6x') < (card.ability.extra.num / card.ability.extra.den) then
                    return { x_mult = card.ability.extra.amt, card = card, message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.amt } } }
                end
            end
        end
    end
}

SMODS.Atlas { key = "prob_9", path = "j_prob_9.png", px = 71, py = 95 }
SMODS.Joker {
    key = "prob_9",
    loc_txt = {
        name = "Pick Pocket",
        text = {
            "{C:green}#1# in #2#{} chance for",
            "each scored card to give {C:money}+$#3#{}"
        }
    },
    config = { extra = { num = 1, den = 3, amt = 2 } },
    rarity = 2, cost = 6, atlas = "prob_9", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.num, card.ability.extra.den, card.ability.extra.amt } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                if pseudorandom('lim_p3$') < (card.ability.extra.num / card.ability.extra.den) then
                    return { dollars = card.ability.extra.amt, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "prob_10", path = "j_prob_10.png", px = 71, py = 95 }
SMODS.Joker {
    key = "prob_10",
    loc_txt = {
        name = "Heist",
        text = {
            "{C:green}#1# in #2#{} chance for",
            "each scored card to give {C:money}+$#3#{}"
        }
    },
    config = { extra = { num = 1, den = 4, amt = 3 } },
    rarity = 2, cost = 6, atlas = "prob_10", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.num, card.ability.extra.den, card.ability.extra.amt } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                if pseudorandom('lim_p4$') < (card.ability.extra.num / card.ability.extra.den) then
                    return { dollars = card.ability.extra.amt, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "prob_11", path = "j_prob_11.png", px = 71, py = 95 }
SMODS.Joker {
    key = "prob_11",
    loc_txt = {
        name = "Smash & Grab",
        text = {
            "{C:green}#1# in #2#{} chance for",
            "each scored card to give {C:money}+$#3#{}"
        }
    },
    config = { extra = { num = 1, den = 5, amt = 5 } },
    rarity = 2, cost = 6, atlas = "prob_11", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.num, card.ability.extra.den, card.ability.extra.amt } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                if pseudorandom('lim_p5$') < (card.ability.extra.num / card.ability.extra.den) then
                    return { dollars = card.ability.extra.amt, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "cond_first_hand", path = "j_cond_first_hand.png", px = 71, py = 95 }
SMODS.Joker {
    key = "cond_first_hand",
    loc_txt = {
        name = "Early Bird",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "on your {C:attention}first hand{} of each round"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "cond_first_hand", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (G.GAME.current_round.hands_left == G.GAME.round_resets.hands - 1) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "cond_no_discard", path = "j_cond_no_discard.png", px = 71, py = 95 }
SMODS.Joker {
    key = "cond_no_discard",
    loc_txt = {
        name = "Hold the Line",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "if {C:attention}no discards{} were used"
        }
    },
    config = { extra = { x_mult = 2.0 } },
    rarity = 2, cost = 7, atlas = "cond_no_discard", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (G.GAME.current_round.discards_left == G.GAME.round_resets.discards) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "cond_full_discard", path = "j_cond_full_discard.png", px = 71, py = 95 }
SMODS.Joker {
    key = "cond_full_discard",
    loc_txt = {
        name = "Burnt Out",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "if {C:attention}all discards{} were used"
        }
    },
    config = { extra = { x_mult = 2.5 } },
    rarity = 2, cost = 7, atlas = "cond_full_discard", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (G.GAME.current_round.discards_left == 0) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "cond_five_played", path = "j_cond_five_played.png", px = 71, py = 95 }
SMODS.Joker {
    key = "cond_five_played",
    loc_txt = {
        name = "Maximalist",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "if you played a {C:attention}full 5-card hand{}"
        }
    },
    config = { extra = { x_mult = 2.0 } },
    rarity = 2, cost = 7, atlas = "cond_five_played", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (context.full_hand and #context.full_hand == 5) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "cond_one_played", path = "j_cond_one_played.png", px = 71, py = 95 }
SMODS.Joker {
    key = "cond_one_played",
    loc_txt = {
        name = "Minimalist",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "if you played {C:attention}exactly 1 card{}"
        }
    },
    config = { extra = { x_mult = 3.0 } },
    rarity = 2, cost = 7, atlas = "cond_one_played", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (context.full_hand and #context.full_hand == 1) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "cond_two_played", path = "j_cond_two_played.png", px = 71, py = 95 }
SMODS.Joker {
    key = "cond_two_played",
    loc_txt = {
        name = "Dynamic Duo",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "if you played {C:attention}exactly 2 cards{}"
        }
    },
    config = { extra = { x_mult = 2.0 } },
    rarity = 2, cost = 7, atlas = "cond_two_played", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (context.full_hand and #context.full_hand == 2) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "cond_after_skip", path = "j_cond_after_skip.png", px = 71, py = 95 }
SMODS.Joker {
    key = "cond_after_skip",
    loc_txt = {
        name = "Shortcut",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "if any Blind has been skipped this run"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "cond_after_skip", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (G.GAME.skips and G.GAME.skips > 0) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "cond_first_blind", path = "j_cond_first_blind.png", px = 71, py = 95 }
SMODS.Joker {
    key = "cond_first_blind",
    loc_txt = {
        name = "Sandbagger",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "on a {C:attention}Small Blind{}"
        }
    },
    config = { extra = { x_mult = 2.0 } },
    rarity = 2, cost = 7, atlas = "cond_first_blind", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (G.GAME.round_resets.ante and G.GAME.blind and G.GAME.blind.boss == false) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "cond_late_ante", path = "j_cond_late_ante.png", px = 71, py = 95 }
SMODS.Joker {
    key = "cond_late_ante",
    loc_txt = {
        name = "Veteran",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "from {C:attention}Ante 5{} onward"
        }
    },
    config = { extra = { x_mult = 2.0 } },
    rarity = 2, cost = 7, atlas = "cond_late_ante", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (G.GAME.round_resets.ante and G.GAME.round_resets.ante >= 5) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "cond_low_money", path = "j_cond_low_money.png", px = 71, py = 95 }
SMODS.Joker {
    key = "cond_low_money",
    loc_txt = {
        name = "Underdog",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "if you have {C:money}$4{} or less"
        }
    },
    config = { extra = { x_mult = 2.5 } },
    rarity = 2, cost = 7, atlas = "cond_low_money", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (G.GAME.dollars and G.GAME.dollars <= 4) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "cond_high_money", path = "j_cond_high_money.png", px = 71, py = 95 }
SMODS.Joker {
    key = "cond_high_money",
    loc_txt = {
        name = "Fat Cat",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "if you have {C:money}$20{} or more"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 7, atlas = "cond_high_money", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (G.GAME.dollars and G.GAME.dollars >= 20) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "cond_hand_full", path = "j_cond_hand_full.png", px = 71, py = 95 }
SMODS.Joker {
    key = "cond_hand_full",
    loc_txt = {
        name = "Brimming",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "if your hand is at {C:attention}max size{}"
        }
    },
    config = { extra = { x_mult = 1.75 } },
    rarity = 2, cost = 7, atlas = "cond_hand_full", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (G.hand and #G.hand.cards >= G.hand.config.card_limit) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "rt_rightmost", path = "j_rt_rightmost.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rt_rightmost",
    loc_txt = {
        name = "Mirror Image",
        text = {
            "Retriggers the {C:attention}rightmost{}",
            "scored card {C:attention}#1#{} additional time"
        }
    },
    config = { extra = { reps = 1 } },
    rarity = 2, cost = 7, atlas = "rt_rightmost", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.reps } }
    end,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play
                and context.scoring_hand and (context.other_card == context.scoring_hand[#context.scoring_hand]) then
            return { message = localize('k_again_ex'), repetitions = card.ability.extra.reps, card = card }
        end
    end
}

SMODS.Atlas { key = "rt_hearts", path = "j_rt_hearts.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rt_hearts",
    loc_txt = {
        name = "Hall of Mirrors",
        text = {
            "Retriggers each scored",
            "{C:hearts}Hearts{} {C:attention}#1#{} additional time"
        }
    },
    config = { extra = { reps = 1 } },
    rarity = 2, cost = 7, atlas = "rt_hearts", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.reps } }
    end,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play then
            local p = context.other_card
            if p and p:is_suit("Hearts") then
                return { message = localize('k_again_ex'), repetitions = card.ability.extra.reps, card = card }
            end
        end
    end
}

SMODS.Atlas { key = "rt_diamonds", path = "j_rt_diamonds.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rt_diamonds",
    loc_txt = {
        name = "Disco Ball",
        text = {
            "Retriggers each scored",
            "{C:diamonds}Diamonds{} {C:attention}#1#{} additional time"
        }
    },
    config = { extra = { reps = 1 } },
    rarity = 2, cost = 7, atlas = "rt_diamonds", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.reps } }
    end,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play then
            local p = context.other_card
            if p and p:is_suit("Diamonds") then
                return { message = localize('k_again_ex'), repetitions = card.ability.extra.reps, card = card }
            end
        end
    end
}

SMODS.Atlas { key = "rt_clubs", path = "j_rt_clubs.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rt_clubs",
    loc_txt = {
        name = "Club Replay",
        text = {
            "Retriggers each scored",
            "{C:clubs}Clubs{} {C:attention}#1#{} additional time"
        }
    },
    config = { extra = { reps = 1 } },
    rarity = 2, cost = 7, atlas = "rt_clubs", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.reps } }
    end,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play then
            local p = context.other_card
            if p and p:is_suit("Clubs") then
                return { message = localize('k_again_ex'), repetitions = card.ability.extra.reps, card = card }
            end
        end
    end
}

SMODS.Atlas { key = "rt_spades", path = "j_rt_spades.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rt_spades",
    loc_txt = {
        name = "Spade Echo",
        text = {
            "Retriggers each scored",
            "{C:spades}Spades{} {C:attention}#1#{} additional time"
        }
    },
    config = { extra = { reps = 1 } },
    rarity = 2, cost = 7, atlas = "rt_spades", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.reps } }
    end,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play then
            local p = context.other_card
            if p and p:is_suit("Spades") then
                return { message = localize('k_again_ex'), repetitions = card.ability.extra.reps, card = card }
            end
        end
    end
}

SMODS.Atlas { key = "rt_faces", path = "j_rt_faces.png", px = 71, py = 95 }
SMODS.Joker {
    key = "rt_faces",
    loc_txt = {
        name = "Court Repeater",
        text = {
            "Retriggers each scored",
            "{C:attention}face card{} {C:attention}#1#{} additional time"
        }
    },
    config = { extra = { reps = 1 } },
    rarity = 3, cost = 8, atlas = "rt_faces", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.reps } }
    end,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play then
            local p = context.other_card
            if p then
                local r = p:get_id()
                if r and ((r >= 11 and r <= 13)) then
                    return { message = localize('k_again_ex'), repetitions = card.ability.extra.reps, card = card }
                end
            end
        end
    end
}

SMODS.Atlas { key = "econ_eor_3", path = "j_econ_eor_3.png", px = 71, py = 95 }
SMODS.Joker {
    key = "econ_eor_3",
    loc_txt = {
        name = "Coin Purse",
        text = {
            "Earns {C:money}$#1#{} at",
            "end of round"
        }
    },
    config = { extra = { dollars = 3 } },
    rarity = 1, cost = 5, atlas = "econ_eor_3", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.dollars } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.individual and not context.repetition and not context.blueprint then
            return { dollars = card.ability.extra.dollars }
        end
    end
}

SMODS.Atlas { key = "econ_eor_5", path = "j_econ_eor_5.png", px = 71, py = 95 }
SMODS.Joker {
    key = "econ_eor_5",
    loc_txt = {
        name = "Wallet",
        text = {
            "Earns {C:money}$#1#{} at",
            "end of round"
        }
    },
    config = { extra = { dollars = 5 } },
    rarity = 1, cost = 5, atlas = "econ_eor_5", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.dollars } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.individual and not context.repetition and not context.blueprint then
            return { dollars = card.ability.extra.dollars }
        end
    end
}

SMODS.Atlas { key = "econ_eor_8", path = "j_econ_eor_8.png", px = 71, py = 95 }
SMODS.Joker {
    key = "econ_eor_8",
    loc_txt = {
        name = "Money Bag",
        text = {
            "Earns {C:money}$#1#{} at",
            "end of round"
        }
    },
    config = { extra = { dollars = 8 } },
    rarity = 1, cost = 5, atlas = "econ_eor_8", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.dollars } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.individual and not context.repetition and not context.blueprint then
            return { dollars = card.ability.extra.dollars }
        end
    end
}

SMODS.Atlas { key = "econ_per_joker", path = "j_econ_per_joker.png", px = 71, py = 95 }
SMODS.Joker {
    key = "econ_per_joker",
    loc_txt = {
        name = "Loan Shark",
        text = {
            "Earns {C:money}$#1#{} per",
            "Joker held",
            "at end of round"
        }
    },
    config = { extra = { dollars = 1 } },
    rarity = 1, cost = 5, atlas = "econ_per_joker", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.dollars } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.individual and not context.repetition and not context.blueprint then
            local n = (G.jokers and #G.jokers.cards) or 0
            if n and n > 0 then
                return { dollars = card.ability.extra.dollars * n }
            end
        end
    end
}

SMODS.Atlas { key = "econ_per_consum", path = "j_econ_per_consum.png", px = 71, py = 95 }
SMODS.Joker {
    key = "econ_per_consum",
    loc_txt = {
        name = "Bullion",
        text = {
            "Earns {C:money}$#1#{} per",
            "consumable held",
            "at end of round"
        }
    },
    config = { extra = { dollars = 2 } },
    rarity = 1, cost = 5, atlas = "econ_per_consum", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.dollars } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.individual and not context.repetition and not context.blueprint then
            local n = (G.consumeables and #G.consumeables.cards) or 0
            if n and n > 0 then
                return { dollars = card.ability.extra.dollars * n }
            end
        end
    end
}

SMODS.Atlas { key = "econ_per_disc_left", path = "j_econ_per_disc_left.png", px = 71, py = 95 }
SMODS.Joker {
    key = "econ_per_disc_left",
    loc_txt = {
        name = "Saver",
        text = {
            "Earns {C:money}$#1#{} per",
            "unused discard",
            "at end of round"
        }
    },
    config = { extra = { dollars = 1 } },
    rarity = 1, cost = 5, atlas = "econ_per_disc_left", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.dollars } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.individual and not context.repetition and not context.blueprint then
            local n = G.GAME.current_round.discards_left or 0
            if n and n > 0 then
                return { dollars = card.ability.extra.dollars * n }
            end
        end
    end
}

SMODS.Atlas { key = "econ_per_hand_left", path = "j_econ_per_hand_left.png", px = 71, py = 95 }
SMODS.Joker {
    key = "econ_per_hand_left",
    loc_txt = {
        name = "Hoarder",
        text = {
            "Earns {C:money}$#1#{} per",
            "unused hand",
            "at end of round"
        }
    },
    config = { extra = { dollars = 2 } },
    rarity = 1, cost = 5, atlas = "econ_per_hand_left", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.dollars } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.individual and not context.repetition and not context.blueprint then
            local n = G.GAME.current_round.hands_left or 0
            if n and n > 0 then
                return { dollars = card.ability.extra.dollars * n }
            end
        end
    end
}

SMODS.Atlas { key = "econ_per_ante", path = "j_econ_per_ante.png", px = 71, py = 95 }
SMODS.Joker {
    key = "econ_per_ante",
    loc_txt = {
        name = "Compounding",
        text = {
            "Earns {C:money}$#1#{} per",
            "Ante reached",
            "at end of round"
        }
    },
    config = { extra = { dollars = 1 } },
    rarity = 2, cost = 6, atlas = "econ_per_ante", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.dollars } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.individual and not context.repetition and not context.blueprint then
            local n = G.GAME.round_resets.ante or 0
            if n and n > 0 then
                return { dollars = card.ability.extra.dollars * n }
            end
        end
    end
}

SMODS.Atlas { key = "util_hsize_2", path = "j_util_hsize_2.png", px = 71, py = 95 }
SMODS.Joker {
    key = "util_hsize_2",
    loc_txt = {
        name = "Cargo Pockets",
        text = {
            "{C:attention}+#1#{} hand size"
        }
    },
    config = { extra = { n = 2 } },
    rarity = 2, cost = 6, atlas = "util_hsize_2", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.n } }
    end,
    add_to_deck = function(self, card, from_debuff) G.hand:change_size(card.ability.extra.n) end,
    remove_from_deck = function(self, card, from_debuff) G.hand:change_size(-card.ability.extra.n) end,
    calculate = function(self, card, context)

    end
}

SMODS.Atlas { key = "util_hsize_neg", path = "j_util_hsize_neg.png", px = 71, py = 95 }
SMODS.Joker {
    key = "util_hsize_neg",
    loc_txt = {
        name = "Tunnel Vision",
        text = {
            "{C:attention}#1#{} hand size"
        }
    },
    config = { extra = { n = -1 } },
    rarity = 2, cost = 6, atlas = "util_hsize_neg", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.n } }
    end,
    add_to_deck = function(self, card, from_debuff) G.hand:change_size(card.ability.extra.n) end,
    remove_from_deck = function(self, card, from_debuff) G.hand:change_size(-card.ability.extra.n) end,
    calculate = function(self, card, context)

    end
}

SMODS.Atlas { key = "util_disc_1", path = "j_util_disc_1.png", px = 71, py = 95 }
SMODS.Joker {
    key = "util_disc_1",
    loc_txt = {
        name = "Second Thought",
        text = {
            "{C:attention}+#1#{} discard per round"
        }
    },
    config = { extra = { n = 1 } },
    rarity = 1, cost = 4, atlas = "util_disc_1", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.n } }
    end,
    add_to_deck = function(self, card, from_debuff) G.GAME.round_resets.discards = G.GAME.round_resets.discards + card.ability.extra.n end,
    remove_from_deck = function(self, card, from_debuff) G.GAME.round_resets.discards = G.GAME.round_resets.discards - card.ability.extra.n end,
    calculate = function(self, card, context)

    end
}

SMODS.Atlas { key = "util_disc_2", path = "j_util_disc_2.png", px = 71, py = 95 }
SMODS.Joker {
    key = "util_disc_2",
    loc_txt = {
        name = "Re-Deal",
        text = {
            "{C:attention}+#1#{} discards per round"
        }
    },
    config = { extra = { n = 2 } },
    rarity = 2, cost = 6, atlas = "util_disc_2", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.n } }
    end,
    add_to_deck = function(self, card, from_debuff) G.GAME.round_resets.discards = G.GAME.round_resets.discards + card.ability.extra.n end,
    remove_from_deck = function(self, card, from_debuff) G.GAME.round_resets.discards = G.GAME.round_resets.discards - card.ability.extra.n end,
    calculate = function(self, card, context)

    end
}

SMODS.Atlas { key = "util_hand_1", path = "j_util_hand_1.png", px = 71, py = 95 }
SMODS.Joker {
    key = "util_hand_1",
    loc_txt = {
        name = "One More Try",
        text = {
            "{C:attention}+#1#{} hand per round"
        }
    },
    config = { extra = { n = 1 } },
    rarity = 2, cost = 7, atlas = "util_hand_1", pos = { x = 0, y = 0 },
    blueprint_compat = false, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.n } }
    end,
    add_to_deck = function(self, card, from_debuff) G.GAME.round_resets.hands = G.GAME.round_resets.hands + card.ability.extra.n end,
    remove_from_deck = function(self, card, from_debuff) G.GAME.round_resets.hands = G.GAME.round_resets.hands - card.ability.extra.n end,
    calculate = function(self, card, context)

    end
}

SMODS.Atlas { key = "flat_chips_30", path = "j_flat_chips_30.png", px = 71, py = 95 }
SMODS.Joker {
    key = "flat_chips_30",
    loc_txt = {
        name = "Banner Lite",
        text = {
            "{C:chips}+#1#{} Chips"
        }
    },
    config = { extra = { chips = 30 } },
    rarity = 1, cost = 4, atlas = "flat_chips_30", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            return { chips_mod = card.ability.extra.chips,
                     message = localize{ type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } } }
        end
    end
}

SMODS.Atlas { key = "flat_chips_50", path = "j_flat_chips_50.png", px = 71, py = 95 }
SMODS.Joker {
    key = "flat_chips_50",
    loc_txt = {
        name = "Big Banner",
        text = {
            "{C:chips}+#1#{} Chips"
        }
    },
    config = { extra = { chips = 50 } },
    rarity = 2, cost = 6, atlas = "flat_chips_50", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            return { chips_mod = card.ability.extra.chips,
                     message = localize{ type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } } }
        end
    end
}

SMODS.Atlas { key = "flat_mult_5", path = "j_flat_mult_5.png", px = 71, py = 95 }
SMODS.Joker {
    key = "flat_mult_5",
    loc_txt = {
        name = "Plus Five",
        text = {
            "{C:mult}+#1#{} Mult"
        }
    },
    config = { extra = { mult = 5 } },
    rarity = 1, cost = 4, atlas = "flat_mult_5", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "flat_mult_10", path = "j_flat_mult_10.png", px = 71, py = 95 }
SMODS.Joker {
    key = "flat_mult_10",
    loc_txt = {
        name = "Plus Ten",
        text = {
            "{C:mult}+#1#{} Mult"
        }
    },
    config = { extra = { mult = 10 } },
    rarity = 2, cost = 6, atlas = "flat_mult_10", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            return { mult_mod = card.ability.extra.mult,
                     message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } },
                     colour = G.C.MULT }
        end
    end
}

SMODS.Atlas { key = "flat_x15", path = "j_flat_x15.png", px = 71, py = 95 }
SMODS.Joker {
    key = "flat_x15",
    loc_txt = {
        name = "Steady Hand",
        text = {
            "{X:mult,C:white}X#1#{} Mult"
        }
    },
    config = { extra = { x_mult = 1.25 } },
    rarity = 2, cost = 7, atlas = "flat_x15", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "syn_per_joker", path = "j_syn_per_joker.png", px = 71, py = 95 }
SMODS.Joker {
    key = "syn_per_joker",
    loc_txt = {
        name = "Solidarity",
        text = {
            "{C:mult}+#1#{} Mult per",
            "Joker held"
        }
    },
    config = { extra = { mult = 3 } },
    rarity = 2, cost = 7, atlas = "syn_per_joker", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local n = (G.jokers and #G.jokers.cards) or 0
            if n > 0 then
                return { mult_mod = card.ability.extra.mult * n,
                         message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult * n } },
                         colour = G.C.MULT }
            end
        end
    end
}

SMODS.Atlas { key = "syn_per_uncommon", path = "j_syn_per_uncommon.png", px = 71, py = 95 }
SMODS.Joker {
    key = "syn_per_uncommon",
    loc_txt = {
        name = "Highbrow",
        text = {
            "{C:mult}+#1#{} Mult per",
            "Uncommon Joker"
        }
    },
    config = { extra = { mult = 5 } },
    rarity = 2, cost = 7, atlas = "syn_per_uncommon", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local n = (function() local c=0 for _,j in ipairs(G.jokers and G.jokers.cards or {}) do if j.config and j.config.center and j.config.center.rarity == 2 then c = c + 1 end end return c end)()
            if n > 0 then
                return { mult_mod = card.ability.extra.mult * n,
                         message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult * n } },
                         colour = G.C.MULT }
            end
        end
    end
}

SMODS.Atlas { key = "syn_per_rare", path = "j_syn_per_rare.png", px = 71, py = 95 }
SMODS.Joker {
    key = "syn_per_rare",
    loc_txt = {
        name = "Aristocrat",
        text = {
            "{C:mult}+#1#{} Mult per",
            "Rare Joker"
        }
    },
    config = { extra = { mult = 8 } },
    rarity = 3, cost = 8, atlas = "syn_per_rare", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local n = (function() local c=0 for _,j in ipairs(G.jokers and G.jokers.cards or {}) do if j.config and j.config.center and j.config.center.rarity == 3 then c = c + 1 end end return c end)()
            if n > 0 then
                return { mult_mod = card.ability.extra.mult * n,
                         message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult * n } },
                         colour = G.C.MULT }
            end
        end
    end
}

SMODS.Atlas { key = "syn_per_consum", path = "j_syn_per_consum.png", px = 71, py = 95 }
SMODS.Joker {
    key = "syn_per_consum",
    loc_txt = {
        name = "Library",
        text = {
            "{C:mult}+#1#{} Mult per",
            "consumable held"
        }
    },
    config = { extra = { mult = 4 } },
    rarity = 2, cost = 7, atlas = "syn_per_consum", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local n = (G.consumeables and #G.consumeables.cards) or 0
            if n > 0 then
                return { mult_mod = card.ability.extra.mult * n,
                         message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult * n } },
                         colour = G.C.MULT }
            end
        end
    end
}

SMODS.Atlas { key = "syn_per_face", path = "j_syn_per_face.png", px = 71, py = 95 }
SMODS.Joker {
    key = "syn_per_face",
    loc_txt = {
        name = "Royalist",
        text = {
            "{C:mult}+#1#{} Mult per",
            "face card in deck"
        }
    },
    config = { extra = { mult = 1 } },
    rarity = 2, cost = 7, atlas = "syn_per_face", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local n = (function() local c=0 for _,p in ipairs(G.playing_cards or {}) do local r=p:get_id() if r and r >= 11 and r <= 13 then c = c + 1 end end return c end)()
            if n > 0 then
                return { mult_mod = card.ability.extra.mult * n,
                         message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult * n } },
                         colour = G.C.MULT }
            end
        end
    end
}

SMODS.Atlas { key = "syn_per_ace", path = "j_syn_per_ace.png", px = 71, py = 95 }
SMODS.Joker {
    key = "syn_per_ace",
    loc_txt = {
        name = "Ace Hunter",
        text = {
            "{C:mult}+#1#{} Mult per",
            "Ace in deck"
        }
    },
    config = { extra = { mult = 2 } },
    rarity = 2, cost = 7, atlas = "syn_per_ace", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local n = (function() local c=0 for _,p in ipairs(G.playing_cards or {}) do if p:get_id() == 14 then c = c + 1 end end return c end)()
            if n > 0 then
                return { mult_mod = card.ability.extra.mult * n,
                         message = localize{ type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult * n } },
                         colour = G.C.MULT }
            end
        end
    end
}

SMODS.Atlas { key = "syn_per_joker_x", path = "j_syn_per_joker_x.png", px = 71, py = 95 }
SMODS.Joker {
    key = "syn_per_joker_x",
    loc_txt = {
        name = "Brotherhood",
        text = {
            "{X:mult,C:white}X#1#{} Mult per",
            "Joker held",
            "{C:inactive}(stacks additively)"
        }
    },
    config = { extra = { x_per = 0.1 } },
    rarity = 3, cost = 8, atlas = "syn_per_joker_x", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_per } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local n = (G.jokers and #G.jokers.cards) or 0
            if n > 0 then
                local total = 1 + n * card.ability.extra.x_per
                return { x_mult = total,
                         message = localize{ type = 'variable', key = 'a_xmult', vars = { total } } }
            end
        end
    end
}

SMODS.Atlas { key = "syn_per_consum_x", path = "j_syn_per_consum_x.png", px = 71, py = 95 }
SMODS.Joker {
    key = "syn_per_consum_x",
    loc_txt = {
        name = "Apothecary",
        text = {
            "{X:mult,C:white}X#1#{} Mult per",
            "consumable held",
            "{C:inactive}(stacks additively)"
        }
    },
    config = { extra = { x_per = 0.15 } },
    rarity = 3, cost = 8, atlas = "syn_per_consum_x", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_per } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local n = (G.consumeables and #G.consumeables.cards) or 0
            if n > 0 then
                local total = 1 + n * card.ability.extra.x_per
                return { x_mult = total,
                         message = localize{ type = 'variable', key = 'a_xmult', vars = { total } } }
            end
        end
    end
}

SMODS.Atlas { key = "xt_boss_xmult", path = "j_xt_boss_xmult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "xt_boss_xmult",
    loc_txt = {
        name = "Bossed Up",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "on {C:attention}Boss Blinds{}"
        }
    },
    config = { extra = { x_mult = 2.5 } },
    rarity = 3, cost = 8, atlas = "xt_boss_xmult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (G.GAME.blind and G.GAME.blind.boss) then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "xt_small_xmult", path = "j_xt_small_xmult.png", px = 71, py = 95 }
SMODS.Joker {
    key = "xt_small_xmult",
    loc_txt = {
        name = "Easy Money",
        text = {
            "{X:mult,C:white}X#1#{} Mult",
            "on {C:attention}Small Blinds{}"
        }
    },
    config = { extra = { x_mult = 1.5 } },
    rarity = 2, cost = 6, atlas = "xt_small_xmult", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    calculate = function(self, card, context)
        if context.joker_main and (G.GAME.blind and G.GAME.blind.config and G.GAME.blind.config.blind == 'Small Blind') then
            return { x_mult = card.ability.extra.x_mult,
                     message = localize{ type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } } }
        end
    end
}

SMODS.Atlas { key = "xt_per_card", path = "j_xt_per_card.png", px = 71, py = 95 }
SMODS.Joker {
    key = "xt_per_card",
    loc_txt = {
        name = "More The Merrier",
        text = {
            "{C:mult}+#1#{} Mult per scored card"
        }
    },
    config = { extra = { mult = 4 } },
    rarity = 2, cost = 7, atlas = "xt_per_card", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                return { mult = card.ability.extra.mult, card = card }
            end
        end
    end
}

SMODS.Atlas { key = "xt_per_card_chip", path = "j_xt_per_card_chip.png", px = 71, py = 95 }
SMODS.Joker {
    key = "xt_per_card_chip",
    loc_txt = {
        name = "All Hands",
        text = {
            "{C:chips}+#1#{} Chips per scored card"
        }
    },
    config = { extra = { chips = 20 } },
    rarity = 2, cost = 6, atlas = "xt_per_card_chip", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            local p = context.other_card
            if p and not p.debuff then
                return { chips = card.ability.extra.chips, card = card }
            end
        end
    end
}

SMODS.Atlas { key = "xt_per_held", path = "j_xt_per_held.png", px = 71, py = 95 }
SMODS.Joker {
    key = "xt_per_held",
    loc_txt = {
        name = "Hand-Holder",
        text = {
            "{C:mult}+#1#{} Mult per card",
            "left in hand at scoring"
        }
    },
    config = { extra = { mult = 3 } },
    rarity = 2, cost = 7, atlas = "xt_per_held", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.mult } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round then
            return { mult = card.ability.extra.mult, card = card }
        end
    end
}

SMODS.Atlas { key = "xt_stone", path = "j_xt_stone.png", px = 71, py = 95 }
SMODS.Joker {
    key = "xt_stone",
    loc_txt = {
        name = "Quarry",
        text = {
            "{C:chips}+#1#{} Chips per scored",
            "{C:attention}Stone{} card"
        }
    },
    config = { extra = { chips = 50 } },
    rarity = 2, cost = 7, atlas = "xt_stone", pos = { x = 0, y = 0 },
    blueprint_compat = true, eternal_compat = true, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local p = context.other_card
            if p and not p.debuff then
                if SMODS.has_no_rank and SMODS.has_no_rank(p) then
                    return { chips = card.ability.extra.chips, card = card }
                end
            end
        end
    end
}

----------------------------------------------
------------MOD CODE END----------------------
